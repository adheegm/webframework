<?php
	require 'global.php';
?>