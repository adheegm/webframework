<?php
	echo file_get_contents('../../scripts/json/post.json');
?>