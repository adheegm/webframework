<?php
	echo file_get_contents('../../scripts/json/menu.json');
?>