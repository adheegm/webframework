<?php
	require 'site/page.php';
	require 'site/user.php';
	require 'site/database.php';
	require 'site/cookie.php';
	require 'site/init.php';
?>