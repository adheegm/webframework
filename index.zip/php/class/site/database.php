<?php
	class Database{
		var $server;
		var $port;
		var $username;
		var $password;
		public function __construct(){
			
		}
		
		public function __destruct(){
			
		}
	}
?>