<?php
	class Page{
		public function __construct() {
			
		}
		
		public function __destruct() {
			
		}
	}
?>