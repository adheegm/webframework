<?php
	require 'controller.php';
	require 'model.php';
?>