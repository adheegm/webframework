<!DOCTYPE>
<html lang="en-US">	
	<?php 
		require 'head/index.php'; 
		require 'body/index.php';
	?>		
</html>