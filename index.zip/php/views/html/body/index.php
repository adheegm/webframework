<body>
<noscript>Your browser does not support javascript on your browser is not enabled.</noscript>
<?php
	require 'site/index.php';
?>
</body>