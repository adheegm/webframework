<div id="site">
	<div id="page-wrap">
		<?php require 'content/index.php'; ?>
	</div>
</div>