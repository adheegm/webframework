<?php
	require 'header/index.php';
	require 'section/index.php';
	require 'footer/index.php';
?>
			
			