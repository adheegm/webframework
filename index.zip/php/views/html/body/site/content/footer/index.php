<div id="footer" class="border">
	<a class="site-address" href="http://<?php print $__SITE__HOME__ADDRESS__; ?>"><?php print "http://".$__SITE__HOME__ADDRESS__;  ?></a>
</div>