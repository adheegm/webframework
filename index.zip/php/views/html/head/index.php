<head>
	<meta name="keywords" content="adi winata, technology, programming, .net, c#, html, css, javascript, jquery, mobile, game development, webgl, 3d, php, apache, android, java, open source, music, blues, black blues, texas blues, youtube, facebook, twitter, books, indonesia, sumatera, kalimantan, jawa, sulawesi, papua, bike, mountain">
	<meta name="description" content="Adi Winata's personal website for everythings about what i don't known and what i known. Just share for people who want to learn about everythings. Programming, science, music and live.">
	<meta name="author" content="Adi Winata">
	<meta name="charset" content="UTF-8">
	<base href="http://<?php print $__SITE__HOME__ADDRESS__; ?>/">
	<meta http-equiv="content-type" content="text/html;charset=UTF-8">
	<title><?php print $__SITE__TITLE__; ?></title>
	<link href='http://fonts.googleapis.com/css?family=Gudea&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
	<link href="styles/global.css" rel="stylesheet" type="text/css">
	<!--<script type="text/javascript" src="http://code.jquery.com/jquery-2.1.4.min.js"></script>-->
</head>