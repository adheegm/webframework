<?php
	require 'html/index.php';
	require 'pages/index.php';
?>