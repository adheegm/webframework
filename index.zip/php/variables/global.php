<?php
	/*must have*/
	$GLOBALS['__SITE__TITLE__'] = "Adi Winata's Site";
	$GLOBALS['__SITE__HOSTNAME__'] = "adiwinata";
	$GLOBALS['__SITE__HOME__ADDRESS__'] = "localhost/adiwinata"; /*"http://www.adiwinata.com";*/	
	
	/*database settings*/
	$GLOBALS['__DATABASE__SERVER__'] = "localhost";
	$GLOBALS['__DATABASE__NAME__'] = "adiwinat_site";
	$GLOBALS['__DATABASE_USERNAME__'] = "adiwinat_client";
	$GLOBALS['__DATABASE__PASSWORD__'] = "client_1234";
	
	/*json data location*/
	$GLOBALS['__JSON__FOLDER__'] = "scripts/json";
	
	/*framework*/
	$GLOBALS['__SCRIPT__'] = "php/script";
	$GLOBALS['__STYLES__ '] = "styles";
	$GLOBALS['__CONTROLLER__'] = "php/controller";
	$GLOBALS['__VIEW__'] = "php/views";
	$GLOBALS['__DEFAULT_CONTROLLER__'] = "home";
	
	/*site action*/
	$GLOBALS['__Track__USER__LOG_FILE'] = 'ip_log.txt';
?>