<?php
	require 'variables/index.php';
	require 'core/index.php';
	require 'function/index.php';
	require 'class/index.php';
	require 'controllers/index.php';
	require 'models/index.php';
	require 'views/index.php';				
?>