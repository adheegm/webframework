<?php
	require '/../core/model.php';
	require '/../core/controller.php';
?>