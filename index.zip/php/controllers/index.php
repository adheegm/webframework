<?php
	require 'pages/home.php';
?>